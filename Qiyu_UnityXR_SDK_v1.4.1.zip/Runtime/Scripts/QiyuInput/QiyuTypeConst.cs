﻿//=============================================================================
//
//          Copyright (c) 2022 Beijing Dreamagic Science and Technology Co.,Ltd.
//                          All Rights Reserved.
//
//=============================================================================
namespace Unity.XR.Qiyu
{
    public enum DEVICE_ID
    {
        // HEAD,
        HAND_0 = 0x01,
        HAND_1 = 0x02,
        HAND_0_1 = 0x03
    }
}


