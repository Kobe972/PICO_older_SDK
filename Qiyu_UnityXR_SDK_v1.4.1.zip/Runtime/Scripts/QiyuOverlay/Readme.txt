1、Use QiyuOverlay need add QiyuOverlayManager.cs to XR Camera;
2、Use Underlay type,need close HDR;